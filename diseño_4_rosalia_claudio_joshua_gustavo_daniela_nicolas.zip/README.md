# Actividad en clase para probar el metodo SOLID

![screaming-cat](https://media.tenor.com/3sscVvNm9zkAAAAC/controlmypc-cat.gif)
